<div id="nav_area">
  <!-- <php wp_nav_menu( array( 'container_class' => 'nav-menu', 'theme_location' => 'primary', 'after' => '<span></span>') ); ?> -->
  <small class="nav_toggle">
    <i class="wpburger"><small></small></i>
  </small>

	<div class="toggle_right_nav">
    <nav>
			<div class="menu_slide_right">
          <a href="<?php //echo get_home_url(); ?>" class="logo_slide_right"><img src="images/main_logo.png" alt="<?php //echo get_bloginfo('name');?>"/></a>
          <small>X</small>
      </div>

      <div class="wrapper">
        <ul>
          <li><a href="">Home</a></li>
          <li><a href="">About Us</a></li>
          <li><a href="">Services</a></li>
          <li><a href="">Careers</a></li>
          <li><a href="">Resources</a></li>
          <li><a href="">Contact Us</a></li>
        </ul>
      </div>
    </nav>
		<div class="toggle_nav_close"></div>
	</div>
</div>
