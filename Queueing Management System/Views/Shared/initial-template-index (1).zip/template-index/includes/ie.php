	<!--[if lt IE 11]>
		<div class="dang-ie">

			<div class="container">
				<div class="message">
					<div class="inner-message">
						<a class="ie-logo" href="http://windows.microsoft.com/en-us/internet-explorer/download-ie" target="_blank">
							<img src="<?php bloginfo('template_url'); ?>/images/Internet_Explorer.png" alt="IE Logo"/>
						</a>

						<p>
						You are using an old version of IE. <br/>
						To fully enjoy the site, download the latest version of Internet Explorer.</p>

						<a class="download" href="http://windows.microsoft.com/en-us/internet-explorer/download-ie" target="_blank">Get Internet Explorer 11</a>
						</p>
					</div>
				</div>
			</div>

			<div class="terms">
				Image used is a brand logo owned by <a href="http://www.microsoft.com/en-ph/default.aspx" target="_blank">Microsoft</a>.
			</div>

		</div>

	<![endif]-->
