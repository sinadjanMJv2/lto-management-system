<aside class="sidebar">
  <div class="side_box1">
    <ul>
			<li><a href="#">LinkThis</a></li>
			<li><a href="#">LinkThis</a></li>
			<li><a href="#">LinkThis</a></li>
			<li><a href="#">LinkThis</a></li>
		</ul>
  </div>

  <div class="side_box2">
    <h2>Heading<span>Sub</span></h2>
		<p>TextHere</p>
		<a href="#">LinkThis</a>
  </div>
</aside>
